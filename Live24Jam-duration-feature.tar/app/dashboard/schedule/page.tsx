"use client";

import { useState, useEffect } from "react";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001";

interface Schedule {
    id: number;
    title: string;
    streamId: number;
    videoFile?: string;
    days: string[];
    startTime: string;
    endTime: string;
    active: boolean;
    lastRun?: string;
}

interface Stream {
    id: number;
    title: string;
    platform: string;
    videoFile?: string;
}

interface VideoFile {
    name: string;
    sizeFormatted: string;
}

const dayLabels: { [key: string]: string } = {
    mon: "Sen",
    tue: "Sel",
    wed: "Rab",
    thu: "Kam",
    fri: "Jum",
    sat: "Sab",
    sun: "Min",
};

export default function SchedulePage() {
    const [schedules, setSchedules] = useState<Schedule[]>([]);
    const [streams, setStreams] = useState<Stream[]>([]);
    const [videos, setVideos] = useState<VideoFile[]>([]);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [editingSchedule, setEditingSchedule] = useState<Schedule | null>(null);
    const [formData, setFormData] = useState({
        title: "",
        streamId: "",
        videoFile: "",
        days: [] as string[],
        startTime: "",
        endTime: "",
    });

    // Fetch schedules and streams
    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const [schedulesRes, streamsRes, videosRes] = await Promise.all([
                fetch(`${API_URL}/api/schedules`),
                fetch(`${API_URL}/api/streams`),
                fetch(`${API_URL}/api/videos`)
            ]);

            if (schedulesRes.ok) {
                const data = await schedulesRes.json();
                setSchedules(data);
            }

            if (streamsRes.ok) {
                const data = await streamsRes.json();
                setStreams(data);
            }

            if (videosRes.ok) {
                const data = await videosRes.json();
                setVideos(data);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            setLoading(false);
        }
    };

    const toggleSchedule = async (id: number) => {
        try {
            const response = await fetch(`${API_URL}/api/schedules/${id}/toggle`, {
                method: "POST"
            });
            if (response.ok) {
                const updated = await response.json();
                setSchedules(schedules.map(s => s.id === id ? updated : s));
            }
        } catch (error) {
            console.error("Error toggling schedule:", error);
        }
    };

    const deleteSchedule = async (id: number) => {
        if (!confirm("Yakin mau hapus jadwal ini?")) return;

        try {
            const response = await fetch(`${API_URL}/api/schedules/${id}`, {
                method: "DELETE"
            });
            if (response.ok) {
                setSchedules(schedules.filter(s => s.id !== id));
            }
        } catch (error) {
            console.error("Error deleting schedule:", error);
        }
    };

    const openModal = (schedule?: Schedule) => {
        if (schedule) {
            setEditingSchedule(schedule);
            setFormData({
                title: schedule.title,
                streamId: schedule.streamId.toString(),
                videoFile: schedule.videoFile || "",
                days: schedule.days,
                startTime: schedule.startTime,
                endTime: schedule.endTime,
            });
        } else {
            setEditingSchedule(null);
            setFormData({ title: "", streamId: "", videoFile: "", days: [], startTime: "", endTime: "" });
        }
        setShowModal(true);
    };

    const saveSchedule = async () => {
        if (!formData.title || !formData.streamId || formData.days.length === 0 || !formData.startTime || !formData.endTime) {
            alert("Lengkapi semua field!");
            return;
        }

        try {
            if (editingSchedule) {
                // Update existing
                const response = await fetch(`${API_URL}/api/schedules/${editingSchedule.id}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(formData)
                });
                if (response.ok) {
                    const updated = await response.json();
                    setSchedules(schedules.map(s => s.id === editingSchedule.id ? updated : s));
                }
            } else {
                // Create new
                const response = await fetch(`${API_URL}/api/schedules`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(formData)
                });
                if (response.ok) {
                    const newSchedule = await response.json();
                    setSchedules([...schedules, newSchedule]);
                }
            }
            setShowModal(false);
        } catch (error) {
            console.error("Error saving schedule:", error);
            alert("Gagal menyimpan jadwal");
        }
    };

    const toggleDay = (day: string) => {
        setFormData({
            ...formData,
            days: formData.days.includes(day)
                ? formData.days.filter((d) => d !== day)
                : [...formData.days, day],
        });
    };

    const getStreamTitle = (streamId: number) => {
        const stream = streams.find(s => s.id === streamId);
        return stream?.title || "Unknown Stream";
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <span className="animate-pulse text-gray-400">Memuat jadwal...</span>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Page Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 className="text-2xl md:text-3xl font-bold">Jadwal Stream</h1>
                    <p className="text-gray-400 mt-1">Atur jadwal otomatis untuk live streaming kamu.</p>
                </div>
                <button onClick={() => openModal()} className="btn-primary">
                    + Tambah Jadwal
                </button>
            </div>

            {/* Info Card */}
            <div className="bg-indigo-500/10 border border-indigo-500/30 rounded-xl p-4">
                <p className="text-indigo-400 text-sm">
                    💡 <strong>Cara kerja:</strong> Scheduler akan otomatis memulai dan menghentikan stream sesuai jadwal yang Anda atur. Pastikan stream sudah dikonfigurasi dengan benar di menu Streams.
                </p>
            </div>

            {/* Schedule List */}
            <div className="space-y-4">
                {schedules.map((schedule) => (
                    <div key={schedule.id} className={`card ${!schedule.active && "opacity-60"}`}>
                        <div className="flex flex-col md:flex-row md:items-center gap-4">
                            {/* Info */}
                            <div className="flex-1">
                                <div className="flex items-center gap-3 mb-2">
                                    <h3 className="font-semibold text-lg">{schedule.title}</h3>
                                    <span className={`text-xs px-2 py-1 rounded-full ${schedule.active
                                        ? "bg-green-500/20 text-green-400"
                                        : "bg-gray-500/20 text-gray-400"
                                        }`}>
                                        {schedule.active ? "Aktif" : "Nonaktif"}
                                    </span>
                                </div>

                                <p className="text-gray-500 text-sm mb-1">
                                    📺 {getStreamTitle(schedule.streamId)}
                                </p>
                                {schedule.videoFile && (
                                    <p className="text-gray-500 text-sm mb-2">
                                        🎬 Video: {schedule.videoFile}
                                    </p>
                                )}

                                <div className="flex flex-wrap gap-2 mb-2">
                                    {Object.keys(dayLabels).map((day) => (
                                        <span
                                            key={day}
                                            className={`text-xs px-2 py-1 rounded ${schedule.days.includes(day)
                                                ? "bg-indigo-500/20 text-indigo-400"
                                                : "bg-gray-800 text-gray-600"
                                                }`}
                                        >
                                            {dayLabels[day]}
                                        </span>
                                    ))}
                                </div>

                                <p className="text-gray-400 text-sm">
                                    ⏰ {schedule.startTime} - {schedule.endTime}
                                </p>
                            </div>

                            {/* Actions */}
                            <div className="flex gap-2">
                                <button
                                    onClick={() => toggleSchedule(schedule.id)}
                                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${schedule.active
                                        ? "bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30"
                                        : "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                                        }`}
                                >
                                    {schedule.active ? "Pause" : "Aktifkan"}
                                </button>
                                <button
                                    onClick={() => openModal(schedule)}
                                    className="px-4 py-2 bg-gray-800 text-gray-400 rounded-lg hover:bg-gray-700 transition-colors"
                                >
                                    ✏️ Edit
                                </button>
                                <button
                                    onClick={() => deleteSchedule(schedule.id)}
                                    className="px-4 py-2 bg-gray-800 text-gray-400 rounded-lg hover:bg-red-500/20 hover:text-red-400 transition-colors"
                                >
                                    🗑️
                                </button>
                            </div>
                        </div>
                    </div>
                ))}

                {schedules.length === 0 && (
                    <div className="card text-center py-12">
                        <span className="text-6xl block mb-4">📅</span>
                        <h3 className="text-xl font-semibold mb-2">Belum ada jadwal</h3>
                        <p className="text-gray-400 mb-4">Buat jadwal untuk mengotomasi live streaming kamu</p>
                        <button onClick={() => openModal()} className="btn-primary">
                            + Tambah Jadwal
                        </button>
                    </div>
                )}
            </div>

            {/* Modal */}
            {showModal && (
                <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
                    <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 w-full max-w-md">
                        <h2 className="text-xl font-bold mb-4">
                            {editingSchedule ? "Edit Jadwal" : "Tambah Jadwal Baru"}
                        </h2>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">
                                    Nama Jadwal
                                </label>
                                <input
                                    type="text"
                                    value={formData.title}
                                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 text-white placeholder-gray-500"
                                    placeholder="Contoh: Morning Jazz"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">
                                    Pilih Stream
                                </label>
                                <select
                                    value={formData.streamId}
                                    onChange={(e) => setFormData({ ...formData, streamId: e.target.value })}
                                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 text-white"
                                >
                                    <option value="">-- Pilih Stream --</option>
                                    {streams.map(stream => (
                                        <option key={stream.id} value={stream.id}>
                                            {stream.title} ({stream.platform})
                                        </option>
                                    ))}
                                </select>
                                {streams.length === 0 && (
                                    <p className="text-yellow-400 text-xs mt-1">
                                        ⚠️ Belum ada stream. Buat stream terlebih dahulu.
                                    </p>
                                )}
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">
                                    🎬 Pilih Video
                                </label>
                                <select
                                    value={formData.videoFile}
                                    onChange={(e) => setFormData({ ...formData, videoFile: e.target.value })}
                                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 text-white"
                                >
                                    <option value="">-- Pilih Video --</option>
                                    {videos.map(video => (
                                        <option key={video.name} value={video.name}>
                                            📹 {video.name} ({video.sizeFormatted})
                                        </option>
                                    ))}
                                </select>
                                {videos.length === 0 && (
                                    <p className="text-yellow-400 text-xs mt-1">
                                        ⚠️ Belum ada video. Upload video terlebih dahulu di menu Upload.
                                    </p>
                                )}
                                {formData.videoFile && (
                                    <p className="text-green-400 text-xs mt-1">
                                        ✅ Video dipilih: {formData.videoFile}
                                    </p>
                                )}
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">
                                    Hari
                                </label>
                                <div className="flex flex-wrap gap-2">
                                    {Object.entries(dayLabels).map(([day, label]) => (
                                        <button
                                            key={day}
                                            type="button"
                                            onClick={() => toggleDay(day)}
                                            className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${formData.days.includes(day)
                                                ? "bg-indigo-500 text-white"
                                                : "bg-gray-800 text-gray-400 hover:bg-gray-700"
                                                }`}
                                        >
                                            {label}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">
                                        Jam Mulai
                                    </label>
                                    <input
                                        type="time"
                                        value={formData.startTime}
                                        onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 text-white"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-300 mb-2">
                                        Jam Selesai
                                    </label>
                                    <input
                                        type="time"
                                        value={formData.endTime}
                                        onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:border-indigo-500 text-white"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="flex gap-4 mt-6">
                            <button
                                onClick={() => setShowModal(false)}
                                className="btn-secondary flex-1"
                            >
                                Batal
                            </button>
                            <button onClick={saveSchedule} className="btn-primary flex-1">
                                Simpan
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
